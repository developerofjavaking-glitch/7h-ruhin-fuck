package com.example.apkextractor

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.core.content.pm.PackageInfoCompat
import java.io.File

object AppRepository {

    /** Loads every installed app. Call from a background thread (icons and labels are slow). */
    fun load(context: Context): List<AppEntry> {
        val pm = context.packageManager
        return PmCompat.installedPackages(pm)
            .mapNotNull { pi ->
                val ai = pi.applicationInfo ?: return@mapNotNull null
                AppEntry(
                    label = ai.loadLabel(pm).toString(),
                    packageName = pi.packageName,
                    versionName = pi.versionName ?: "",
                    versionCode = PackageInfoCompat.getLongVersionCode(pi),
                    sourceDir = ai.sourceDir,
                    splitDirs = ai.splitSourceDirs?.toList() ?: emptyList(),
                    isSystem = (ai.flags and ApplicationInfo.FLAG_SYSTEM) != 0,
                    icon = ai.loadIcon(pm),
                    sizeBytes = File(ai.sourceDir).length()
                )
            }
            .sortedBy { it.label.lowercase() }
    }
}
