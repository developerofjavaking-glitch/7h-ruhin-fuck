package com.example.apkextractor

import android.Manifest
import android.content.ClipData
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.concurrent.Executors

/** Shared extract / share / storage-permission logic for the app's screens. */
abstract class BaseActivity : AppCompatActivity() {

    protected val io = Executors.newSingleThreadExecutor()
    private var pendingAction: (() -> Unit)? = null

    /** Runs [action] once the app is allowed to write to Download (only needed up to Android 9). */
    protected fun withStorage(action: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 29 ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
            PackageManager.PERMISSION_GRANTED
        ) {
            action()
            return
        }
        pendingAction = action
        ActivityCompat.requestPermissions(
            this, arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_STORAGE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_STORAGE) return
        val action = pendingAction
        pendingAction = null
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            action?.invoke()
        } else {
            Toast.makeText(this, R.string.storage_denied, Toast.LENGTH_LONG).show()
        }
    }

    protected fun extractApps(apps: List<AppEntry>) {
        if (apps.isEmpty()) return
        withStorage {
            Toast.makeText(this, R.string.extracting, Toast.LENGTH_SHORT).show()
            io.execute {
                var ok = 0
                var failed = 0
                for (app in apps) {
                    try {
                        ApkExtractor.extract(this, app)
                        ok++
                    } catch (e: Exception) {
                        failed++
                    }
                }
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    AlertDialog.Builder(this)
                        .setTitle(R.string.extract_done)
                        .setMessage(getString(R.string.extract_result, ok, failed, "Download/${ApkExtractor.FOLDER}"))
                        .setPositiveButton(android.R.string.ok, null)
                        .show()
                }
            }
        }
    }

    protected fun shareApps(apps: List<AppEntry>) {
        if (apps.isEmpty()) return
        io.execute {
            try {
                val uris = ApkExtractor.prepareShare(this, apps)
                runOnUiThread {
                    if (isFinishing || isDestroyed) return@runOnUiThread
                    val intent = Intent().apply {
                        type = ApkExtractor.MIME_APK
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        if (uris.size == 1) {
                            action = Intent.ACTION_SEND
                            putExtra(Intent.EXTRA_STREAM, uris[0])
                        } else {
                            action = Intent.ACTION_SEND_MULTIPLE
                            putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
                        }
                        clipData = ClipData.newRawUri(null, uris[0]).also { clip ->
                            uris.drop(1).forEach { clip.addItem(ClipData.Item(it)) }
                        }
                    }
                    startActivity(Intent.createChooser(intent, getString(R.string.share_with)))
                }
            } catch (e: Exception) {
                runOnUiThread { toastError(e) }
            }
        }
    }

    protected fun toastError(e: Exception) {
        Toast.makeText(this, getString(R.string.error_generic, e.message ?: e.javaClass.simpleName), Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        io.shutdown()
    }

    private companion object {
        const val REQ_STORAGE = 100
    }
}
