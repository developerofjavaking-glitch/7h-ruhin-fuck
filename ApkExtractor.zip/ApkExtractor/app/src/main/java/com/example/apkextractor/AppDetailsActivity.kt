package com.example.apkextractor

import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.text.format.Formatter
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.pm.PackageInfoCompat
import java.io.File
import java.util.Date

/** Shows label, package, version, dates, path, permissions and features of one app. */
class AppDetailsActivity : BaseActivity() {

    private var entry: AppEntry? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val packageName = intent.getStringExtra(EXTRA_PACKAGE)
        val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_CONFIGURATIONS
        val info = packageName?.let { PmCompat.packageInfo(packageManager, it, flags) }
        val ai = info?.applicationInfo
        if (info == null || ai == null) {
            finish()
            return
        }

        val icon = ai.loadIcon(packageManager)
        val label = ai.loadLabel(packageManager).toString()
        entry = AppEntry(
            label = label,
            packageName = info.packageName,
            versionName = info.versionName ?: "",
            versionCode = PackageInfoCompat.getLongVersionCode(info),
            sourceDir = ai.sourceDir,
            splitDirs = ai.splitSourceDirs?.toList() ?: emptyList(),
            isSystem = false,
            icon = icon,
            sizeBytes = File(ai.sourceDir).length()
        )

        findViewById<ImageView>(R.id.icon).setImageDrawable(icon)
        val rows = findViewById<LinearLayout>(R.id.rows)

        addRow(rows, R.string.label_name, label)
        addRow(rows, R.string.label_package, info.packageName)
        addRow(rows, R.string.label_version, "${info.versionName ?: "-"} (${PackageInfoCompat.getLongVersionCode(info)})")
        addRow(
            rows, R.string.label_min_sdk,
            if (Build.VERSION.SDK_INT >= 24) "API ${ai.minSdkVersion}" else "-"
        )
        addRow(rows, R.string.label_target_sdk, "API ${ai.targetSdkVersion}")
        addRow(rows, R.string.label_installed, formatDate(info.firstInstallTime))
        addRow(rows, R.string.label_updated, formatDate(info.lastUpdateTime))
        addRow(rows, R.string.label_path, ai.sourceDir)
        addRow(rows, R.string.label_size, Formatter.formatFileSize(this, File(ai.sourceDir).length()))
        addRow(
            rows, R.string.label_permissions,
            info.requestedPermissions?.joinToString("\n") ?: getString(R.string.none)
        )
        addRow(
            rows, R.string.label_features,
            info.reqFeatures?.mapNotNull { it.name }?.joinToString("\n")?.ifEmpty { null }
                ?: getString(R.string.none)
        )
    }

    private fun formatDate(millis: Long): String =
        DateFormat.getMediumDateFormat(this).format(Date(millis)) + " " +
            DateFormat.getTimeFormat(this).format(Date(millis))

    private fun addRow(parent: LinearLayout, labelRes: Int, value: String) {
        val label = TextView(this).apply {
            setText(labelRes)
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(12), 0, 0)
        }
        val text = TextView(this).apply {
            this.text = value
            textSize = 14f
            setTextIsSelectable(true)
        }
        val lp = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        parent.addView(label, lp)
        parent.addView(text, lp)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.details, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val app = entry
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            R.id.action_extract -> {
                if (app != null) extractApps(listOf(app))
                true
            }
            R.id.action_share -> {
                if (app != null) shareApps(listOf(app))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    companion object {
        const val EXTRA_PACKAGE = "package_name"
    }
}
