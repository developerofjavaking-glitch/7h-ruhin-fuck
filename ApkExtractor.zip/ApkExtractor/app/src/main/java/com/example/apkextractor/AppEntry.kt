package com.example.apkextractor

import android.graphics.drawable.Drawable

/** One installed application, as shown in the list. */
data class AppEntry(
    val label: String,
    val packageName: String,
    val versionName: String,
    val versionCode: Long,
    val sourceDir: String,
    val splitDirs: List<String>,
    val isSystem: Boolean,
    val icon: Drawable,
    val sizeBytes: Long
)
