package com.example.apkextractor

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Bundle
import android.view.ActionMode
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SearchView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : BaseActivity() {

    private lateinit var adapter: AppAdapter
    private lateinit var progress: ProgressBar
    private lateinit var empty: TextView

    private var allApps: List<AppEntry> = emptyList()
    private var showSystem = false
    private var query = ""
    private var actionMode: ActionMode? = null

    /** Refreshes the list whenever an app is installed, updated or removed. */
    private val packageReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) = loadApps()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progress = findViewById(R.id.progress)
        empty = findViewById(R.id.empty)

        adapter = AppAdapter(
            onClick = { app ->
                if (actionMode != null) toggleSelection(app) else showAppDialog(app)
            },
            onLongClick = { app ->
                if (actionMode == null) startActionMode(callback)
                toggleSelection(app)
            },
            onMore = { anchor, app -> showContextMenu(anchor, app) }
        )
        findViewById<RecyclerView>(R.id.recycler).apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            addItemDecoration(DividerItemDecoration(this@MainActivity, DividerItemDecoration.VERTICAL))
            adapter = this@MainActivity.adapter
        }

        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_REPLACED)
            addDataScheme("package")
        }
        ContextCompat.registerReceiver(this, packageReceiver, filter, ContextCompat.RECEIVER_EXPORTED)

        loadApps()
    }

    override fun onDestroy() {
        unregisterReceiver(packageReceiver)
        super.onDestroy()
    }

    // ---- data -----------------------------------------------------------------------------

    private fun loadApps() {
        progress.visibility = View.VISIBLE
        io.execute {
            val apps = try {
                AppRepository.load(this)
            } catch (e: Exception) {
                emptyList()
            }
            runOnUiThread {
                if (isFinishing || isDestroyed) return@runOnUiThread
                allApps = apps
                progress.visibility = View.GONE
                applyFilter()
            }
        }
    }

    private fun applyFilter() {
        val q = query.trim()
        val list = allApps.filter { app ->
            (showSystem || !app.isSystem) &&
                (q.isEmpty() ||
                    app.label.contains(q, ignoreCase = true) ||
                    app.packageName.contains(q, ignoreCase = true))
        }
        adapter.submit(list)
        empty.visibility = if (list.isEmpty() && progress.visibility != View.VISIBLE) View.VISIBLE else View.GONE
        supportActionBar?.subtitle = getString(R.string.apps_count, list.size)
        actionMode?.invalidate()
    }

    // ---- options menu ---------------------------------------------------------------------

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        val search = menu.findItem(R.id.action_search).actionView as SearchView
        search.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(text: String?) = true
            override fun onQueryTextChange(text: String?): Boolean {
                query = text.orEmpty()
                applyFilter()
                return true
            }
        })
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        menu.findItem(R.id.action_show_system).isChecked = showSystem
        return super.onPrepareOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean = when (item.itemId) {
        R.id.action_show_system -> {
            showSystem = !showSystem
            applyFilter()
            true
        }
        R.id.action_extract_all -> {
            confirmExtractAll()
            true
        }
        R.id.action_export_list -> {
            exportList()
            true
        }
        R.id.action_refresh -> {
            loadApps()
            true
        }
        else -> super.onOptionsItemSelected(item)
    }

    private fun confirmExtractAll() {
        val apps = adapter.itemsSnapshot
        if (apps.isEmpty()) return
        AlertDialog.Builder(this)
            .setMessage(getString(R.string.extract_all_confirm, apps.size))
            .setPositiveButton(R.string.menu_extract) { _, _ -> extractApps(apps) }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }

    /** Writes "name  |  package  |  version" for every listed app to a text file. */
    private fun exportList() {
        val apps = adapter.itemsSnapshot
        if (apps.isEmpty()) return
        withStorage {
            io.execute {
                try {
                    val text = apps.joinToString("\n") { "${it.label}  |  ${it.packageName}  |  ${it.versionName}" }
                    ApkExtractor.saveToDownloads(this, "app_list.txt", "text/plain") {
                        it.write(text.toByteArray())
                    }
                    runOnUiThread {
                        Toast.makeText(
                            this,
                            getString(R.string.list_exported, "Download/${ApkExtractor.FOLDER}/app_list.txt"),
                            Toast.LENGTH_LONG
                        ).show()
                    }
                } catch (e: Exception) {
                    runOnUiThread { toastError(e) }
                }
            }
        }
    }

    // ---- single app actions ---------------------------------------------------------------

    private fun showAppDialog(app: AppEntry) {
        val actions = arrayOf(
            getString(R.string.action_extract_apk),
            getString(R.string.action_share_apk),
            getString(R.string.action_app_info)
        )
        AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(actions) { _, which ->
                when (which) {
                    0 -> extractApps(listOf(app))
                    1 -> shareApps(listOf(app))
                    2 -> openDetails(app)
                }
            }
            .show()
    }

    private fun showContextMenu(anchor: View, app: AppEntry) {
        PopupMenu(this, anchor).apply {
            menuInflater.inflate(R.menu.item_context, menu)
            setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    R.id.ctx_info -> openDetails(app)
                    R.id.ctx_uninstall -> startActivity(
                        Intent(Intent.ACTION_DELETE, Uri.parse("package:${app.packageName}"))
                    )
                    R.id.ctx_run -> {
                        val launch = packageManager.getLaunchIntentForPackage(app.packageName)
                        if (launch != null) startActivity(launch)
                        else Toast.makeText(this@MainActivity, R.string.cannot_launch, Toast.LENGTH_SHORT).show()
                    }
                }
                true
            }
            show()
        }
    }

    private fun openDetails(app: AppEntry) {
        startActivity(
            Intent(this, AppDetailsActivity::class.java)
                .putExtra(AppDetailsActivity.EXTRA_PACKAGE, app.packageName)
        )
    }

    // ---- multi-select (action mode) -------------------------------------------------------

    private fun toggleSelection(app: AppEntry) {
        adapter.toggle(app)
        if (adapter.selectedCount == 0) actionMode?.finish() else actionMode?.invalidate()
    }

    private val callback = object : ActionMode.Callback {
        override fun onCreateActionMode(mode: ActionMode, menu: Menu): Boolean {
            mode.menuInflater.inflate(R.menu.action_mode, menu)
            actionMode = mode
            adapter.setSelectionMode(true)
            return true
        }

        override fun onPrepareActionMode(mode: ActionMode, menu: Menu): Boolean {
            mode.title = getString(R.string.selected_count, adapter.selectedCount)
            return true
        }

        override fun onActionItemClicked(mode: ActionMode, item: MenuItem): Boolean {
            when (item.itemId) {
                R.id.action_select_all -> {
                    adapter.selectAll()
                    mode.invalidate()
                }
                R.id.action_extract -> {
                    extractApps(adapter.selectedApps())
                    mode.finish()
                }
                R.id.action_share -> {
                    shareApps(adapter.selectedApps())
                    mode.finish()
                }
            }
            return true
        }

        override fun onDestroyActionMode(mode: ActionMode) {
            actionMode = null
            adapter.setSelectionMode(false)
        }
    }
}
