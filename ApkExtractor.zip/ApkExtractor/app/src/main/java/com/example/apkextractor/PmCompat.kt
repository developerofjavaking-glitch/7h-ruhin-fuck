package com.example.apkextractor

import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.os.Build

/** Hides the API 33 deprecation of the PackageManager query methods. */
object PmCompat {

    fun installedPackages(pm: PackageManager, flags: Int = 0): List<PackageInfo> =
        if (Build.VERSION.SDK_INT >= 33) {
            pm.getInstalledPackages(PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            @Suppress("DEPRECATION")
            pm.getInstalledPackages(flags)
        }

    fun packageInfo(pm: PackageManager, packageName: String, flags: Int = 0): PackageInfo? =
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                pm.getPackageInfo(packageName, PackageManager.PackageInfoFlags.of(flags.toLong()))
            } else {
                @Suppress("DEPRECATION")
                pm.getPackageInfo(packageName, flags)
            }
        } catch (e: PackageManager.NameNotFoundException) {
            null
        }
}
