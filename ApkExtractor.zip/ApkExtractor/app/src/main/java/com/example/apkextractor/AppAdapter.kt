package com.example.apkextractor

import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.text.format.Formatter
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class AppAdapter(
    private val onClick: (AppEntry) -> Unit,
    private val onLongClick: (AppEntry) -> Unit,
    private val onMore: (View, AppEntry) -> Unit
) : RecyclerView.Adapter<AppAdapter.Holder>() {

    private var items: List<AppEntry> = emptyList()
    private val selected = linkedSetOf<String>()
    private var selectionMode = false

    val selectedCount: Int get() = selected.size
    val itemsSnapshot: List<AppEntry> get() = items

    fun submit(list: List<AppEntry>) {
        items = list
        selected.retainAll(list.map { it.packageName }.toSet())
        notifyDataSetChanged()
    }

    fun setSelectionMode(enabled: Boolean) {
        selectionMode = enabled
        if (!enabled) selected.clear()
        notifyDataSetChanged()
    }

    fun toggle(app: AppEntry) {
        if (!selected.add(app.packageName)) selected.remove(app.packageName)
        val index = items.indexOfFirst { it.packageName == app.packageName }
        if (index >= 0) notifyItemChanged(index)
    }

    fun selectAll() {
        selected.addAll(items.map { it.packageName })
        notifyDataSetChanged()
    }

    fun selectedApps(): List<AppEntry> = items.filter { it.packageName in selected }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false))

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: Holder, position: Int) {
        val app = items[position]
        val context = holder.itemView.context
        holder.icon.setImageDrawable(app.icon)
        holder.name.text = app.label
        holder.details.text = buildString {
            append(app.packageName)
            if (app.versionName.isNotEmpty()) append("  •  v").append(app.versionName)
            append("  •  ").append(Formatter.formatShortFileSize(context, app.sizeBytes))
        }
        val isSelected = app.packageName in selected
        holder.check.visibility = if (selectionMode) View.VISIBLE else View.GONE
        holder.check.isChecked = isSelected
        holder.more.visibility = if (selectionMode) View.GONE else View.VISIBLE
        holder.row.background = if (isSelected) {
            ColorDrawable(context.getColor(R.color.selected_row))
        } else {
            holder.defaultBackground.constantState?.newDrawable() ?: holder.defaultBackground
        }
        holder.row.setOnClickListener { onClick(app) }
        holder.row.setOnLongClickListener { onLongClick(app); true }
        holder.more.setOnClickListener { onMore(it, app) }
    }

    class Holder(view: View) : RecyclerView.ViewHolder(view) {
        val row: View = view.findViewById(R.id.row)
        val defaultBackground: Drawable = row.background
        val icon: ImageView = view.findViewById(R.id.icon)
        val name: TextView = view.findViewById(R.id.name)
        val details: TextView = view.findViewById(R.id.details)
        val check: CheckBox = view.findViewById(R.id.check)
        val more: ImageButton = view.findViewById(R.id.more)
    }
}
