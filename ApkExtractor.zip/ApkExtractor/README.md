# App to APK Extractor (Kotlin)

Installed app list -> extract / share APK files. Rewritten as a clean Android Studio project.

Features: app list with search, show/hide system apps, tap for Extract / Share / App Info,
long-press multi-select (Extract, Share), per-row menu (App Info, Uninstall, Run),
Extract all, export app list as text, auto refresh on install/uninstall, App Info screen.

Open the folder in Android Studio (Hedgehog or newer, JDK 17) and run.
APKs are saved to Download/ExtractedApks. Package id: com.example.apkextractor (change in app/build.gradle.kts).
